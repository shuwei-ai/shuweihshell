"""In-process pure-Python package manager for HarmonyOS NEXT sandbox.
Supports querying PyPI, downloading pure-Python wheels, and installing them into site-packages.
"""
from .installer import install, uninstall, list_installed, show, main

__version__ = "24.0.0-harmonyos"
__all__ = ["install", "uninstall", "list_installed", "show", "main"]
