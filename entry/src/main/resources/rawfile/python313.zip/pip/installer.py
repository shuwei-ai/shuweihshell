import os, sys, io, json, re, zipfile, shutil, urllib.request

SITE_PACKAGES = '/data/storage/el2/base/haps/entry/files/site-packages'

def _ensure_site_packages():
    os.makedirs(SITE_PACKAGES, exist_ok=True)
    if SITE_PACKAGES not in sys.path:
        sys.path.insert(0, SITE_PACKAGES)

def _parse_pkg_name(req_str):
    m = re.match(r'^([a-zA-Z0-9_\-]+)', req_str.strip())
    return m.group(1).lower() if m else req_str.strip().lower()

def _get_installed_version(pkg_name):
    _ensure_site_packages()
    pkg_clean = _parse_pkg_name(pkg_name).replace('-', '_').lower()
    if not os.path.exists(SITE_PACKAGES):
        return None
    for item in os.listdir(SITE_PACKAGES):
        if item.lower().startswith(pkg_clean) and item.endswith('.dist-info'):
            m = re.match(r'^[a-zA-Z0-9_]+-([0-9a-zA-Z\.\-]+)\.dist-info$', item)
            if m:
                return m.group(1)
    return None

def list_installed():
    _ensure_site_packages()
    pkgs = {}
    if not os.path.exists(SITE_PACKAGES):
        return pkgs
    for item in os.listdir(SITE_PACKAGES):
        if item.endswith('.dist-info'):
            meta_path = os.path.join(SITE_PACKAGES, item, 'METADATA')
            if os.path.exists(meta_path):
                name, version = None, None
                with open(meta_path, 'r', encoding='utf-8', errors='ignore') as f:
                    for line in f:
                        if line.startswith('Name:'):
                            name = line.split(':', 1)[1].strip()
                        elif line.startswith('Version:'):
                            version = line.split(':', 1)[1].strip()
                        if name and version:
                            break
                if name and version:
                    pkgs[name.lower()] = version
    return pkgs

def show(pkg_name):
    clean_name = _parse_pkg_name(pkg_name)
    pkg_clean = clean_name.replace('-', '_')
    for item in os.listdir(SITE_PACKAGES):
        if item.lower().startswith(pkg_clean) and item.endswith('.dist-info'):
            meta_path = os.path.join(SITE_PACKAGES, item, 'METADATA')
            if os.path.exists(meta_path):
                with open(meta_path, 'r', encoding='utf-8', errors='ignore') as f:
                    print(f.read())
                return
    print(f"Package '{clean_name}' is not installed in {SITE_PACKAGES}")

def uninstall(pkg_name):
    _ensure_site_packages()
    clean_name = _parse_pkg_name(pkg_name)
    pkg_clean = clean_name.replace('-', '_')
    found = False
    for item in list(os.listdir(SITE_PACKAGES)):
        full_path = os.path.join(SITE_PACKAGES, item)
        if item.lower().startswith(pkg_clean) and (item.endswith('.dist-info') or item.lower() == pkg_clean):
            print(f"Removing {full_path}...")
            if os.path.isdir(full_path):
                shutil.rmtree(full_path, ignore_errors=True)
            else:
                os.remove(full_path)
            found = True
    if found:
        print(f"Successfully uninstalled {clean_name}")
    else:
        print(f"Package '{clean_name}' not found in {SITE_PACKAGES}")

def _fetch_pypi_meta(clean_name, timeout=20):
    mirrors = [
        f"https://pypi.tuna.tsinghua.edu.cn/pypi/{clean_name}/json",
        f"https://pypi.org/pypi/{clean_name}/json"
    ]
    last_err = None
    for url in mirrors:
        try:
            req = urllib.request.Request(url, headers={'User-Agent': 'pip-harmonyos/1.0'})
            with urllib.request.urlopen(req, timeout=timeout) as resp:
                return json.loads(resp.read().decode('utf-8'))
        except Exception as e:
            last_err = e
            continue
    raise RuntimeError(f"Failed to query PyPI for '{clean_name}': {last_err}")

def _download_file(download_url, timeout=30):
    # Try Tsinghua mirror first if URL points to files.pythonhosted.org
    candidate_urls = []
    if "files.pythonhosted.org" in download_url:
        candidate_urls.append(download_url.replace("https://files.pythonhosted.org", "https://pypi.tuna.tsinghua.edu.cn"))
    candidate_urls.append(download_url)

    last_err = None
    for url in candidate_urls:
        try:
            req = urllib.request.Request(url, headers={'User-Agent': 'pip-harmonyos/1.0'})
            with urllib.request.urlopen(req, timeout=timeout) as resp:
                return resp.read()
        except Exception as e:
            last_err = e
            continue
    raise RuntimeError(f"Failed to download wheel from {download_url}: {last_err}")

def install(pkg_name, timeout=30, install_deps=True):
    _ensure_site_packages()
    clean_name = _parse_pkg_name(pkg_name)
    current_ver = _get_installed_version(clean_name)
    if current_ver:
        print(f"Requirement already satisfied: {clean_name} ({current_ver}) in {SITE_PACKAGES}")
        return True

    print(f"Collecting {clean_name}...")
    data = _fetch_pypi_meta(clean_name, timeout=timeout)

    urls = data.get('urls', [])
    pure_wheel = None
    for u in urls:
        fn = u.get('filename', '')
        if fn.endswith(('-py3-none-any.whl', '-py2.py3-none-any.whl', '-none-any.whl')):
            pure_wheel = u
            break

    if not pure_wheel:
        c_wheels = [u.get('filename') for u in urls if u.get('filename', '').endswith('.whl')]
        if c_wheels:
            raise RuntimeError(
                f"Package '{clean_name}' only provides compiled binary wheels (e.g. {c_wheels[0]}).\n"
                f"Compiled C-extensions (.so) cannot be dynamically loaded due to HarmonyOS NEXT W^X security policies.\n"
                f"Only pure-Python packages (py3-none-any) can be installed dynamically."
            )
        raise RuntimeError(f"No suitable pure-Python wheel found for '{clean_name}'.")

    whl_name = pure_wheel.get('filename')
    download_url = pure_wheel.get('url')
    size_kb = pure_wheel.get('size', 0) / 1024
    print(f"Downloading {whl_name} ({size_kb:.1f} KB)...")

    whl_bytes = _download_file(download_url, timeout=timeout)

    print(f"Installing {clean_name} into {SITE_PACKAGES}...")
    with zipfile.ZipFile(io.BytesIO(whl_bytes)) as z:
        z.extractall(SITE_PACKAGES)

    new_ver = _get_installed_version(clean_name) or data.get('info', {}).get('version', '')
    print(f"Successfully installed {clean_name}-{new_ver}")

    if install_deps:
        requires_dist = data.get('info', {}).get('requires_dist') or []
        for req in requires_dist:
            # Skip extra dependencies (e.g. extra == 'dev', extra == 'all')
            if 'extra ==' in req or 'extra==' in req:
                continue
            if 'python_version <' in req or 'python_version<=' in req:
                # We are Python 3.13, so skip dependencies only needed for older Pythons
                if any(v in req for v in ['2.7', '3.5', '3.6', '3.7', '3.8', '3.9', '3.10', '3.11', '3.12']):
                    continue
            dep_clean = _parse_pkg_name(req.split(';')[0])
            if dep_clean and not _get_installed_version(dep_clean):
                try:
                    install(dep_clean, timeout=timeout, install_deps=False)
                except Exception as dep_err:
                    print(f"Note: Optional or sub-dependency {dep_clean} failed to install: {dep_err}")

    return True

def main(args=None):
    if args is None:
        args = sys.argv[1:]
    if not args:
        print("Usage: pip install <pkg> | pip list | pip show <pkg> | pip uninstall <pkg>")
        return 0

    cmd = args[0]
    if cmd == 'install':
        for pkg in args[1:]:
            if not pkg.startswith('-'):
                try:
                    install(pkg)
                except Exception as e:
                    print(f"ERROR: {e}")
                    return 1
    elif cmd == 'list':
        pkgs = list_installed()
        print(f"Installed packages in {SITE_PACKAGES} ({len(pkgs)}):")
        for n, v in sorted(pkgs.items()):
            print(f"  {n} == {v}")
    elif cmd == 'show':
        for pkg in args[1:]:
            show(pkg)
    elif cmd == 'uninstall':
        for pkg in args[1:]:
            uninstall(pkg)
    else:
        print(f"Unknown command: {cmd}")
    return 0
