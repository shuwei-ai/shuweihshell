# Basic 8x8 font representation for ASCII characters 32-126
class BitmapFont:
    def __init__(self):
        self.size = 8

    def getbbox(self, text):
        return (0, 0, len(text) * 8, 8)

    def getsize(self, text):
        return (len(text) * 8, 8)

_default_font = BitmapFont()

def load_default():
    return _default_font
