import re

NAMED_COLORS = {
    "white": (255, 255, 255), "black": (0, 0, 0), "red": (255, 0, 0),
    "green": (0, 128, 0), "blue": (0, 0, 255), "yellow": (255, 255, 0),
    "cyan": (0, 255, 255), "magenta": (255, 0, 255), "gray": (128, 128, 128),
    "grey": (128, 128, 128), "lightgray": (211, 211, 211), "darkgray": (169, 169, 169),
    "orange": (255, 165, 0), "purple": (128, 0, 128), "pink": (255, 192, 203),
    "lime": (0, 255, 0), "navy": (0, 0, 128), "teal": (0, 128, 128),
    "silver": (192, 192, 192), "gold": (255, 215, 0), "transparent": (0, 0, 0, 0)
}

def getrgb(color):
    if isinstance(color, (tuple, list)):
        return tuple(color)
    if isinstance(color, int):
        return (color, color, color)
    if not isinstance(color, str):
        return (0, 0, 0)
    c = color.strip().lower()
    if c in NAMED_COLORS:
        return NAMED_COLORS[c]
    if c.startswith('#'):
        c = c[1:]
        if len(c) == 3:
            return (int(c[0]*2, 16), int(c[1]*2, 16), int(c[2]*2, 16))
        if len(c) == 6:
            return (int(c[0:2], 16), int(c[2:4], 16), int(c[4:6], 16))
        if len(c) == 8:
            return (int(c[0:2], 16), int(c[2:4], 16), int(c[4:6], 16), int(c[6:8], 16))
    m = re.match(r'rgba?\((\d+),\s*(\d+),\s*(\d+)(?:,\s*([\d\.]+))?\)', c)
    if m:
        r, g, b = int(m.group(1)), int(m.group(2)), int(m.group(3))
        a = int(float(m.group(4)) * 255) if m.group(4) else 255
        return (r, g, b, a)
    return (0, 0, 0)
