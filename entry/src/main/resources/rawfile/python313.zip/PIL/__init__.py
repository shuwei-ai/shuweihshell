"""Pure-Python Lightweight PIL compatibility layer for mobile sandboxes."""
from . import Image, ImageDraw, ImageColor, ImageFont

__version__ = "10.2.0-purepy"
