import os, io, sys
from . import ImageColor

try:
    import png
except ImportError:
    png = None

class Image:
    def __init__(self, mode="RGB", size=(1, 1), color=(255, 255, 255)):
        self.mode = mode.upper()
        self.width, self.height = size
        self.size = size
        c = ImageColor.getrgb(color)
        if self.mode == "RGB":
            default_pixel = (c[0], c[1], c[2])
        elif self.mode == "RGBA":
            default_pixel = (c[0], c[1], c[2], c[3] if len(c) > 3 else 255)
        elif self.mode == "L":
            default_pixel = c[0]
        else:
            default_pixel = (c[0], c[1], c[2])
        # Internal buffer: 2D array of pixels [y][x]
        self._pixels = [[default_pixel for _ in range(self.width)] for _ in range(self.height)]

    def putpixel(self, xy, color):
        x, y = int(xy[0]), int(xy[1])
        if 0 <= x < self.width and 0 <= y < self.height:
            c = ImageColor.getrgb(color)
            if self.mode == "RGB":
                self._pixels[y][x] = (c[0], c[1], c[2])
            elif self.mode == "RGBA":
                self._pixels[y][x] = (c[0], c[1], c[2], c[3] if len(c) > 3 else 255)
            elif self.mode == "L":
                self._pixels[y][x] = c[0]

    def getpixel(self, xy):
        x, y = int(xy[0]), int(xy[1])
        if 0 <= x < self.width and 0 <= y < self.height:
            return self._pixels[y][x]
        return (0, 0, 0)

    def copy(self):
        new_img = Image(self.mode, self.size)
        new_img._pixels = [row[:] for row in self._pixels]
        return new_img

    def save(self, fp, format=None, **params):
        if png is None:
            raise RuntimeError("pypng is required for saving PNG images")
        
        # Flatten pixels for png writer
        rows = []
        is_rgba = (self.mode == "RGBA")
        is_l = (self.mode == "L")
        
        for y in range(self.height):
            row = []
            for x in range(self.width):
                p = self._pixels[y][x]
                if is_rgba:
                    row.extend(p[:4])
                elif is_l:
                    row.append(p if isinstance(p, int) else p[0])
                else:
                    row.extend(p[:3])
            rows.append(row)

        writer = png.Writer(
            width=self.width,
            height=self.height,
            greyscale=is_l,
            alpha=is_rgba
        )

        close_after = False
        if isinstance(fp, str):
            import builtins; out_file = builtins.open(fp, "wb")
            close_after = True
        else:
            out_file = fp

        try:
            writer.write(out_file, rows)
        finally:
            if close_after:
                out_file.close()

def new(mode, size, color=(255, 255, 255)):
    return Image(mode, size, color)

def open(fp):
    if png is None:
        raise RuntimeError("pypng is required for loading PNG images")
    reader = png.Reader(filename=fp if isinstance(fp, str) else None, file=fp if not isinstance(fp, str) else None)
    w, h, pixels, meta = reader.read()
    mode = "RGBA" if meta.get("alpha") else ("L" if meta.get("greyscale") else "RGB")
    img = Image(mode, (w, h))
    plane = meta.get("planes", 3)
    for y, row in enumerate(pixels):
        for x in range(w):
            idx = x * plane
            if plane == 4:
                img.putpixel((x, y), (row[idx], row[idx+1], row[idx+2], row[idx+3]))
            elif plane == 3:
                img.putpixel((x, y), (row[idx], row[idx+1], row[idx+2]))
            else:
                img.putpixel((x, y), row[idx])
    return img
